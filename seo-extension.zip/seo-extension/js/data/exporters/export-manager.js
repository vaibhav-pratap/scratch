/**
 * Export Manager
 * Aggregates data from various sources for comprehensive reporting
 */

import { getKeywordsData } from '../../services/keywords.js';
import { getLastAnalysis } from '../renderers/ai-analysis.js';
import { getPlannerResults } from '../../ui/keywords-planner.js';
import { getTrendsResults } from '../../ui/keywords-ideas.js';

export async function collectAllData(coreData) {
    console.log('[ExportManager] Collecting comprehensive data...');

    // 1. Start with core SEO data (Meta, CWV, Headings, Images, Links, Schema, Tech, etc.)
    const fullData = {
        ...coreData,
        exportDate: new Date().toISOString(),
        keywords: {
            performance: null,
            planner: [],
            trends: []
        },
        aiAnalysis: null
    };

    // 2. Fetch Keywords Performance Data (GSC)
    try {
        const keywordsState = getKeywordsData();
        if (keywordsState) {
            fullData.keywords.performance = {
                domain: keywordsState.domain,
                dateRange: keywordsState.dateRange,
                queries: keywordsState.queries,
                pages: keywordsState.pages,
                totals: keywordsState.totals
            };
        }
    } catch (e) {
        console.warn('[ExportManager] Could not collect keywords performance data:', e);
    }

    // 3. Fetch AI Analysis Data
    try {
        const aiData = getLastAnalysis();
        if (aiData) {
            fullData.aiAnalysis = aiData;
        }
    } catch (e) {
        console.warn('[ExportManager] Could not collect AI data:', e);
    }

    // 4. Fetch Keyword Planner Data
    try {
        const plannerData = getPlannerResults();
        if (plannerData && Array.isArray(plannerData) && plannerData.length > 0) {
            fullData.keywords.planner = plannerData;
        }
    } catch (e) {
        console.warn('[ExportManager] Could not collect planner data:', e);
    }

    // 5. Fetch Keyword Trends (Ideas) Data
    try {
        const trendsData = getTrendsResults();
        if (trendsData && Array.isArray(trendsData) && trendsData.length > 0) {
            fullData.keywords.trends = trendsData;
        }
    } catch (e) {
        console.warn('[ExportManager] Could not collect trends data:', e);
    }

    return fullData;
}
